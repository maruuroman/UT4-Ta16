function About() {
  return (
    <div>
      <h2>About Page</h2>
      <p>This is the About page where you can learn more about us.</p>
    </div>
  );
}

export default About;
